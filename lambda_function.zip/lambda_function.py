def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': 'Ola do Terraform na AWS Sandbox!'
    }
